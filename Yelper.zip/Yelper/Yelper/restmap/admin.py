from django.contrib import admin
from datetime import datetime
import pandas as pd
import pandas_gbq
import time
from google.oauth2 import service_account
import numpy as np
import random
# import matplotlib
# import matplotlib.pyplot as plt

# Register your models here.

from restmap.models import YelpUser

class YelpAdmin():
	pass

admin.site.register(YelpUser)

#credentials = service_account.Credentials.from_service_account_file('/Users/riddhiman/Desktop/BigData/final_project/Yelp 2/restmap/homework-1-e5246a2433ce.json')
credentials = service_account.Credentials.from_service_account_file('/home/dd2676/anaconda3/Django/mapping/bigdata-hw01-c97798e29011.json')
print("CREDENTIALS: ", credentials)
pandas_gbq.context.credentials = credentials

pandas_gbq.context.project = "bigdata-hw01"

#SQL = "SELECT DISTINCT user_id FROM `homework-1-294021.recommendations.recs`"
SQL = "SELECT DISTINCT user_id FROM `bigdata-hw01.Final_Project.recs2`"


df = pandas_gbq.read_gbq(SQL)
print(df)
df_list = df.to_dict('records')

data_list = []

for df_row in df_list:
	data_list.append({'user_id':df_row['user_id']})
print(len(df_list))
for i in range(len(df_list)):
	print(data_list[i]['user_id'])
	yu = YelpUser(user_id = data_list[i]['user_id']).save()
	
