from django.apps import AppConfig


class RestmapConfig(AppConfig):
    name = 'restmap'
